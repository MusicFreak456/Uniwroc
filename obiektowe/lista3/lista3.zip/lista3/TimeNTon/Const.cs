using System;

namespace Const
{
    public class Consts
    {
        public static int N = 5;
    }
}