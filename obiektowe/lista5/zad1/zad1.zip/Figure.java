
abstract public class Figure implements Comparable<Figure>
{
    

}