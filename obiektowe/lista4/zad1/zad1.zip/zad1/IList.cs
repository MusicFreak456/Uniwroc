
interface IList<T>
{
    void addBack(T newValue);
    bool isEmpty();
    string ToString();
}