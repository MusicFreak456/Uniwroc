var searchData=
[
  ['scale_40',['Scale',['../classScale.html',1,'']]],
  ['scalesfmlwindow_41',['ScaleSFMLWindow',['../classScaleSFMLWindow.html',1,'']]]
];
